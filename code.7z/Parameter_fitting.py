# 前期准备，数据文件读取转换等操作
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import calendar
import math
from random import random
from scipy.optimize import minimize
from scipy.optimize import curve_fit
from functools import partial
# 读取数据文件 
day_data=pd.read_excel('data.xlsx',sheet_name=0)
month_data=pd.read_excel('data.xlsx',sheet_name=1)
I0_dict=month_data.set_index('month')['I0'].to_dict() #月份与I0对应的字典


# 将北京时间转换为当地真太阳时,单位：小时
def bj_to_local_time(bj_time,lng):
    real_sun_time=bj_time+(lng-120)/15
    return real_sun_time


# 计算日期序号,从该年1月1日为1，每天递增1
def date_index(year, month, day):
    days_in_month = {
        1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
        7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
    }

    total_days = day
    for m in range(1, month):
        total_days += days_in_month[m]
        if m == 2 and calendar.isleap(year):
            total_days += 1

    return total_days

# 太阳时角的计算
def sun_time_angle(lng,bj_time):
    # 计算太阳真时
    real_time=bj_to_local_time(bj_time,lng)
    # 计算太阳时角
    theta=15*(real_time-12)
    return theta

#赤纬角的计算
def zenith_angle(year,month,day):
    x=2*math.pi*(284+date_index(year,month,day))/365
    delta=23.45*math.sin(x)
    return delta


#太阳高度角计算
def sun_height_angle(lat,lng,bj_time,year,month,day):
    sina=math.sin(math.radians(lat))*math.sin(math.radians(zenith_angle(year,month,day)))+math.cos(math.radians(lat))*math.cos(math.radians(zenith_angle(year,month,day)))*math.cos(math.radians(sun_time_angle(lng,bj_time)))
    alpha=math.asin(sina)
    return alpha*180/math.pi

# 太阳方位角的计算
def sun_direction_angle(lat,lng,bj_time,year,month,day):
    #sinA=-math.sin(math.radians(sun_time_angle(lng,bj_time)))*math.cos(math.radians(zenith_angle(year,month,day)))/math.cos(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))
    # return sinA
    cosA=(math.sin(math.radians(zenith_angle(year,month,day)))-math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))*math.sin(math.radians(lat)))/(math.cos(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))*math.cos(math.radians(lat)))
    if(sun_time_angle(lng,bj_time)<0):
        A=math.acos(cosA)
    else:
        A=2*math.pi-math.acos(cosA)
    return A*180/math.pi


# 太阳直射穿透大气层距离
def penetrate_dist(lat,lng,bj_time,year,month,day):
    r=6371.393 #地球半径，单位：公里
    x=(-r*math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))+math.sqrt(r**2*(math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))**2-(r**2-(r+d_atm)**2))
    return x

 # 大气层对太阳辐射的损失函数，输出为经过大气层到达地面的太阳直射辐射强度
def atm_loss(year,month,day,bj_time,lng,lat,d_atm,miu,k):
    r=6371.393 #地球半径，单位：公里
    x=(-r*math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))+math.sqrt(r**2*(math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))**2-(r**2-(r+d_atm)**2))
    I_1=I0_dict[month]*np.exp(-miu*x+k)
    return I_1

# 对数型模型，加速损失函数求解
def atm_loss_ln(year,month,day,bj_time,lng,lat,d_atm,miu,k):
    r=6371.393 #地球半径，单位：公里
    x=(-r*math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))+math.sqrt(r**2*(math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))**2-(r**2-(r+d_atm)**2))
    ln_I1=math.log(I0_dict[month])-miu*x+k
    return ln_I1

# 求解miu用到的损失函数
def loss_func(miu,k):# bj_time为列表
    loss=0
    for i in range(len(bj_time)):
        time=bj_time.iloc[i]
        lnI_1=atm_loss_ln(year,month,day,time,lng,lat,d_atm,miu,k)
        loss += (lnI_1-math.log(real_I1.iloc[i]))**2
    return loss

# 定义目标函数
def target_function(params):
    miu,k= params
    # 计算目标函数的值
    result = loss_func(miu,k)  # 请用你的实际目标函数来替换
    return result

if __name__ == '__main__':
    # 模型调试
    real_I1=day_data['I_ground'][3:24]
    bj_time=(day_data['bj_h']+day_data['bj_m']/60)[3:24]#将时间单位化为小时的pandas series
    year=2023
    month=5
    day=23
    d_atm=1000 #大气层厚度，单位：千米
    # 该地的经纬度：
    lat=30.583
    lng=114.317
    result= minimize(target_function, [0.01,10], method='Nelder-Mead', options={'disp': True})
    print("最小化目标函数的参数估计值:", result.x)
    print("最小化目标函数的最小损失估计值:", result.fun)
    miu=result.x[0]
    k=result.x[1]
    for i in range(len(bj_time)):
        time=bj_time.iloc[i]
        I_1=atm_loss(year,month,day,time,lng,lat,d_atm,miu,k)
        print(I_1)
        # dist=penetrate_dist(lat,lng,time,year,month,day)
        # print(dist)
