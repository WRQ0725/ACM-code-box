# 前期准备，数据文件读取转换等操作
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import calendar
import math
from random import random
from scipy.optimize import minimize
from scipy.optimize import curve_fit
from functools import partial
import scipy.integrate as spi
# 读取数据文件 
day_data=pd.read_excel('data.xlsx',sheet_name=0)
month_data=pd.read_excel('data.xlsx',sheet_name=1)
I0_dict=month_data.set_index('month')['I0'].to_dict() #月份与I0对应的字典


# 将北京时间转换为当地真太阳时,单位：小时
def bj_to_local_time(bj_time,lng):
    real_sun_time=bj_time+(lng-120)/15
    return real_sun_time


# 计算日期序号,从该年1月1日为1，每天递增1
def date_index(year, month, day):
    days_in_month = {
        1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
        7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
    }

    total_days = day
    for m in range(1, month):
        total_days += days_in_month[m]
        if m == 2 and calendar.isleap(year):
            total_days += 1

    return total_days

# 太阳时角的计算
def sun_time_angle(lng,bj_time):
    # 计算太阳真时
    real_time=bj_to_local_time(bj_time,lng)
    # 计算太阳时角
    theta=15*(real_time-12)
    return theta

#赤纬角的计算
def zenith_angle(year,month,day):
    x=2*math.pi*(284+date_index(year,month,day))/365
    delta=23.45*math.sin(x)
    return delta


#太阳高度角计算
def sun_height_angle(lat,lng,bj_time,year,month,day):
    sina=math.sin(math.radians(lat))*math.sin(math.radians(zenith_angle(year,month,day)))+math.cos(math.radians(lat))*math.cos(math.radians(zenith_angle(year,month,day)))*math.cos(math.radians(sun_time_angle(lng,bj_time)))
    alpha=math.asin(sina)
    return alpha*180/math.pi

# 太阳方位角的计算
def sun_direction_angle(lat,lng,bj_time,year,month,day):
    #sinA=-math.sin(math.radians(sun_time_angle(lng,bj_time)))*math.cos(math.radians(zenith_angle(year,month,day)))/math.cos(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))
    # return sinA
    cosA=(math.sin(math.radians(zenith_angle(year,month,day)))-math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))*math.sin(math.radians(lat)))/(math.cos(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))*math.cos(math.radians(lat)))
    if(sun_time_angle(lng,bj_time)<0):
        A=math.acos(cosA)
    else:
        A=2*math.pi-math.acos(cosA)
    return A*180/math.pi


# 太阳直射穿透大气层距离
def penetrate_dist(lat,lng,bj_time,year,month,day):
    r=6371.393 #地球半径，单位：公里
    x=(-r*math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))+math.sqrt(r**2*(math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))**2-(r**2-(r+d_atm)**2))
    return x

 # 大气层对太阳辐射的损失函数，输出为经过大气层到达地面的太阳直射辐射强度
def atm_loss(year,month,day,bj_time,lng,lat,d_atm,miu,k):
    r=6371.393 #地球半径，单位：公里
    x=(-r*math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))+math.sqrt(r**2*(math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day))))**2-(r**2-(r+d_atm)**2))
    I_1=I0_dict[month]*np.exp(-miu*x+k)
    return I_1


# 光伏板位置确定，输出光伏板法向量
def panel_direction(dir_angle,up_angle):
    return[math.sin(math.radians(up_angle))*math.cos(math.radians(dir_angle)),math.sin(math.radians(dir_angle))*math.sin(math.radians(up_angle)),math.cos(math.radians(up_angle))]

# 太阳直射光方向向量确定，输出太阳直射光方向向量
def sun_direct_vector(lat,lng,bj_time,year,month,day):
    dir_angle=sun_direction_angle(lat,lng,bj_time,year,month,day)
    return[-math.cos(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))*math.cos(math.radians(sun_direction_angle(lat,lng,bj_time,year,month,day))),math.cos(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))*math.sin(math.radians(sun_direction_angle(lat,lng,bj_time,year,month,day))),math.sin(math.radians(sun_height_angle(lat,lng,bj_time,year,month,day)))]




def instant_sun_radiation(lat,lng,bj_time,year,month,day,dir_angle,up_angle):
    # 计算地面太阳直射辐射强度
    I_1=atm_loss(year,month,day,bj_time,lng,lat,d_atm,0.00103288,0.52034504)#这里使用之前Parameter_fitting.py中计算的miu和k
    # 计算太阳直射光方向向量
    sun_direct=sun_direct_vector(lat,lng,bj_time,year,month,day)
    # 计算光伏板法向量
    panel_direct=panel_direction(dir_angle,up_angle)
    # 计算太阳直射光在光伏板上的投射强度
    I_direct=I_1*np.dot(panel_direct,sun_direct)
    return I_direct


def objective_function1(bj_time,month,angle):
    # # 计算地面太阳直射辐射强度
    # I_1=atm_loss(year,month,day,bj_time,lng,lat,d_atm,0.00103288,0.52034504)
    # # 计算太阳直射光方向向量
    # sun_direct=sun_direct_vector(lat,lng,bj_time,year,month,day)
    # # 计算光伏板法向量
    # panel_direct=panel_direction(dir_angle,up_angle)
    # # 计算太阳直射光在光伏板上的投射强度
    # I_direct=I_1*np.dot(panel_direct,sun_direct)
    # return - I_direct
    return - instant_sun_radiation(lat,lng,bj_time,year,month,day,dir_angle,angle)


def objective_function2(bj_time,month,angle):
    return instant_sun_radiation(lat,lng,bj_time,year,month,day,dir_angle,angle)
# 根据年月日确定当天太阳升起和落下的北京时间
def get_sun_time(year,month,day):
    start_time=0
    end_time=0
    step=0.01
    while True:
        if(sun_height_angle(lat,lng,start_time,year,month,day)<0):
            start_time+=step
        else:
            break
    end_time=start_time
    while True:
        if(sun_height_angle(lat,lng,end_time,year,month,day)>0):
            end_time+=step
        else:
            break
    return start_time,end_time







if __name__ == '__main__':

    # 第一问求解：
    # 1.1 计算三种仰角下各月15日的最大太阳直射强度
    year=2025
    month=list(range(1,13))
    day=15
    d_atm=1000 #大气层厚度，单位：千米
    # 该地的经纬度：
    lat=30.583
    lng=114.317
    #光伏板姿态
    dir_angle=0
    up_angle=[20,40,60]
    MAX_I=pd.DataFrame(columns=['20','40','60'])
    # for m in month:
    #     for angle in up_angle:
    #         print(f'{angle}仰角')
    #         partial_objective_function = partial(objective_function1, month=m, angle=angle)
    #         result = minimize(partial_objective_function, 12, method='Nelder-Mead')
    #         optimal_bj_time = result.x[0]
    #         max_radiation = -result.fun
    #         print(f"{m}月15日{angle}仰角的最优北京时间", optimal_bj_time)
    #         print(f"{m}月15日{angle}仰角的最大太阳直射辐射强度Max radiation:", max_radiation)
    #         MAX_I.loc[m,str(angle)]=max_radiation
    # MAX_I.to_excel('Max_I.xlsx')

    # 1.2 太阳辐射总能量
    SUM_I=pd.DataFrame(columns=['20','40','60'])
    for m in month:
        for angle in up_angle:
            # 确定该月15日太阳升起落下的北京时间（定义域）
            start_time,end_time=get_sun_time(year,m,15)
            # 计算该倾角下该月15日太阳直射辐射总能量
            partial_objective_function = partial(objective_function2, month=m, angle=angle)
            result,error=spi.quad(partial_objective_function,start_time,end_time)
            print(f"{m}月15日{angle}仰角的太阳辐射总能量:", result)
            print("error:",error)
            SUM_I.loc[m,str(angle)]=result
    SUM_I.to_excel('SUM_I.xlsx')

